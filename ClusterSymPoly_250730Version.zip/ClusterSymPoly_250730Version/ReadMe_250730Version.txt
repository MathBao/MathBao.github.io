%% This version is 25.07.30
% The associated Matlab programs can be downloaded at the homepage of Bao Leizhen: mathbao.github.io
% All programs can be run on Matlab Online: matlab.mathworks.com
% If you have any questions, please email one of the authors, Bao Leizhen: mathbao@zju.edu.cn



%% Copy the code from each example to the command line to run it and get the results.

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PART 1
% Find a cluster symmetric polynomial of a cluster symmetric map or a seed


%% ------- EXAMPLE 1
% % Find invariant Laurent polynomial of Example 2.25 for $\tilde{\alpha} = 5, \tilde{\beta} = 3$
% %% Input Data
%% the seedlet $\omega_s = (b, r, Z)$
b = [0,1,-1,-1,1];  % tuple $\mathbf{b}$
r = 1;               
Z = [3, 5]; % coefficients of the polynomial Z(u)=3+5u

s = 1;  % direction $s$
sigma = [2,3,4,5,1]; % permuation $\sigma_{(12345)}$, where sigma(i) is $\sigma_{(12345)}(i)$
eta = [2,3,4,3,2]; % $\bm\eta$
d = [1,1,1,1,1];   % $\mathbf{d}$

%% Solve the system of homogeneous linear equation $HLE(\sigma, s, \omega_s, \bm{\eta}, \mathbf{d})$
FindTheLaurentPolyOf(b,r,Z,s,sigma,eta,d);




%% ------- EXAMPLE 2
% Find invariant Laurent polynomial of Question 3.28
% % Input the seed $\Omega = (B, R, \mathbf{Z})$
B = [0, 1,-1;
    -1, 0, 2;
     1,-2, 0];
R = [4,1,1];  % diag(4,1,1)
syms k1 k2    % NOTE: when class(Z) is 'sym', the program will much slow.
Z = [1, k1,k2,k1,1;
     1, 1, 0, 0, 0;
     1, 1, 0, 0, 0];

S = [1;2;3]; % direction list S
Sigma = [1:3; 1:3; 1:3]; % permuation list Sigma
eta = [2,4,4]; % $\bm\eta$
d = [1,2,2];   % $\mathbf{d}$

% % Solve the systems of homogeneous linear equation $HLE(\sigma, s, \omega_s, \bm{\eta}, \mathbf{d})$ for all $s \in S$
FindTheLaurentPolyOf(B,R,Z,S,Sigma,eta,d);




%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PART 2
% Find the set of nontrivial cluster symmetric pair of a Laurent polynomial


%% ---------- Example 1
% Find the set of nontrivial $1$-cluster symmetric pair of Example 5.6(i)
n = 4;                 % rank n
x = sym('x_', [1,n]);  % varibles \mathbf{x}
syms alpha beta        % constants
Tpower = [0,1,2,0;
          2,0,0,1;
          0,2,0,1];
Tcoeff = [alpha,1,beta];
T = Tcoeff*prod(x.^Tpower,2); % poly $T(\mahtbf{x})$
d = zeros(1,n);   % $\mathbf{d}$

%%  Find the set of nontrivial cluster symmetric pair of $x^{-\mathbf{d}}T(\mathbf{x})$.
M = FindTheClusterSymPairOf(T,d,x);  % M is the set



%% ---------- Example 2
%Find the set of nontrivial cluster symmetric pair of Example 5.6(ii)
n = 4;                 % rank n
x = sym('x_', [1,n]);  % varibles \mathbf{x}
syms a b        % constants
Tpower = [1,2,0,0;
          2,1,0,0;
          1,0,2,0;
          1,0,0,2;
          0,1,2,0;
          2,0,0,1;
          0,1,0,2;
          0,2,0,1;
          0,0,2,1];
Tcoeff = [1,1,a,b^2,a,b,b^2,b,a*b];
T = Tcoeff*prod(x.^Tpower,2); % poly $T(\mahtbf{x})$
d = zeros(1,n);   % $\mathbf{d}$

%%  Find the set of nontrivial cluster symmetric pair of $x^{-\mathbf{d}}T(\mathbf{x})$.
M = FindTheClusterSymPairOf(T,d,x);  % M is the set




	

