function M = FindTheClusterSymPairOf(T, d, x)


%% ---------- Example 1
% % Find the set of nontrivial cluster symmetric pair of Example 5.6(i)
% n = 4;                 % rank n
% x = sym('x_', [1,n]);  % varibles \mathbf{x}
% syms alpha beta        % constants
% Tpower = [0,1,2,0;
%           2,0,0,1;
%           0,2,0,1];
% Tcoeff = [alpha,1,beta];
% T = Tcoeff*prod(x.^Tpower,2); % poly $T(\mahtbf{x})$
% d = zeros(1,n);   % $\mathbf{d}$
% 
% %%  Find the set of nontrivial cluster symmetric pair of $x^{-\mathbf{d}}T(\mathbf{x})$.
% M = FindTheClusterSymPairOf(T,d,x);  % M is the set

%% ---------- Example 2
% % Find the set of nontrivial cluster symmetric pair of Example 5.6(ii)
% n = 4;                 % rank n
% x = sym('x_', [1,n]);  % varibles \mathbf{x}
% syms a b        % constants
% Tpower = [1,2,0,0;
%           2,1,0,0;
%           1,0,2,0;
%           1,0,0,2;
%           0,1,2,0;
%           2,0,0,1;
%           0,1,0,2;
%           0,2,0,1;
%           0,0,2,1];
% Tcoeff = [1,1,a,b^2,a,b,b^2,b,a*b];
% T = Tcoeff*prod(x.^Tpower,2); % poly $T(\mahtbf{x})$
% d = zeros(1,n);   % $\mathbf{d}$
% 
% %%  Find the set of nontrivial cluster symmetric pair of $x^{-\mathbf{d}}T(\mathbf{x})$.
% M = FindTheClusterSymPairOf(T,d,x);  % M is the set



% =========================================================================



n = size(x,2);                    %Number of variables
Perm_n = perms(1:n);              %Permutation group S_n
[~, invPerm_n] = sort(Perm_n, 2); % inverse of permutation

syms u; % Z(u)
t_d = sym('td_', [1,n]); % \tilde{d}
assume(t_d,"integer");

%% --------STEP 1 Construct the set $\mathcal{M}_1(F)$
M = cell(0,6);      % is the set of cluster sym pairs
num = 0;            % is #M
recip = zeros(1);   % Z(u) satsifies reciprocity condition?


%% --------STEP 2 Computer $\deg^i T$
eta = zeros(1,n);
for i = 1:1:n
   eta(1,i) = polynomialDegree(T, x(i));
end    

%% --------STEP 3 Construct the set $S$ of nontrivial directions
S = setdiff(find(mod(eta,2)==0), find(eta==0));

%% --------STEP 4 Check each direction
for s = S
    %% --------STEP 5 Construct the set $\Sigma_s$ of potential permutations of direction s
    Sigma_s = zeros(size(Perm_n));
    numSigma_s = 0;
    for sigma_index = 1:1:size(Perm_n,1)
        sigma = Perm_n(sigma_index,:);
        invsigma = invPerm_n(sigma_index,:);
        if and(ismember(invsigma(s),S), eta(1,s)==eta(1,invsigma(s)))
            numSigma_s = numSigma_s+1;
            Sigma_s(numSigma_s, :) = sigma;
        end
    end
    
    %% --------STEP 6 Check each permutation in $\Sigma_s$
    for sigma_index = 1:1:numSigma_s
        %% --------STEP 7 Computer $t = \sigma^{-1}(s)$
        sigma = Sigma_s(sigma_index,:);
        [~, invsigma] = sort(sigma, 2);
        t = invsigma(s);
        %% --------STEP 8 Construct $\tilde{d}$ such that
        % $\sigma(d+\tilde{d}) = d+\tilde{d}, 2(d_s + \tilde{d}_s) = \eta_s$
        tilde_d = t_d;
        tilde_d(1,s) = eta(1,s)/2 - d(1,s);
        check =  zeros(1,n);
        pre_s = s;
        check(pre_s) = 1;
        while sigma(pre_s) ~= s
            pre_s = sigma(pre_s);
            tilde_d(1, pre_s) = eta(1,s)/2 - d(1,pre_s);
            check(pre_s) = 1;
        end
        for i=1:1:n
            if check(i) == 0
                pre_i = i;
                check(pre_i) = 1;
                tilde_d(1, i) = tilde_d(1, i) - d(1,i);
                while sigma(pre_i) ~= i
                    pre_i = sigma(pre_i);
                    tilde_d(1, pre_i) = tilde_d(1, i) + d(1,i) - d(1,pre_i);
                    check(pre_i) = 1;
                end
            end
        end
        %% --------STEP 9~10 Construct polynomial f_{s,i} 与 f_{t,i}
        fs = coeffs(T, x(s), 'all'); % order by descending power
        ft = coeffs(T, x(t), 'all');
        %% --------STEP 11
        K1 = find(fs==0) - 1;
        K2 = eta(s) + 1 - find(ft==0);
        if isequal(sort(K1), sort(K2))
            %% --------STEP 12~14
            K = setdiff(0:eta(1,s), K1); 
            card = 0;
            k0 = max(K(K < eta(1,s)/2));
            %% --------STEP 15~16 Determining the existence of polynomial $P(x)$
            subsft = subs(ft(eta(1,s)-k0+1), x, x(sigma));
            if gcd(subsft, fs(k0+1)) == fs(k0+1)
                Pdk = simplify(subsft/fs(k0+1));
                preP = factor(Pdk, x);
                constant = unique(subs(preP, x, zeros(1,n)));
                constant(constant==0) = 1; %when multiple be 1
                constant = prod(constant);
                P = constant.^(eta(1,s)/2-k0);
                nonconstant = preP(preP ~= constant);
                fact = unique(nonconstant);
                if ~isempty(fact)
                    for j=1:1:size(fact, 2)
                       power_fact = size(find(nonconstant == fact(j)),2);
                       if mod(power_fact, eta(1,s)/2-k0)==0
                           P = P*fact(j).^(power_fact/(eta(1,s)/2-k0));
                       else
                           P = 0;
                           break
                       end
                    end
                end
                if P~=0
                    card = card+1;
                    %% --------STEP 17~19 
                    for k = setdiff(K, k0)
                        if simplify(subs(ft(eta(1,s)-k+1), x, x(sigma))) == simplify(fs(k+1)*P.^(eta(1,s)/2-k))
                            card = card + 1;
                        else
                            break
                        end
                    end
                    if card == size(K,2)
                       %% --------STEP 20~23 Determining the existence of polynomials $Z(u)$
                       % polynomial P(x) = \sum Pitem
                       % Pitem = x^{b_i}
                       % matrix Bdeg = [b_1; ...; b_m], m=size(Pitem,2)
                       [Pcoeff, Pitem] = coeffs(P,x);
                       Bdeg = zeros(size(Pitem,2),n);   
                       for j = 1:1:size(Bdeg,1)
                           for l = 1:1:n
                               Bdeg(j,l) = polynomialDegree(Pitem(j),x(l));
                           end
                       end
                       
                       if isequal(Bdeg, zeros(1,n))   %when P(x) = constant = Pcoeff
                           b = Bdeg;
                           r = Pcoeff-1;
                           Z = sum(u.^(0:r));
                           % Actually, r could be any positive integer
                           % and Z(u) = z_0 + ... + z_ru^r,
                           % where Z(1) = P(x) = Pcoeff.
                           % Here we choice r = Pcoeff-1, for convenience.

                                   % res = mod(Pcoeff, 2);
                                   % switch res
                                   %     case 0
                                   %         r = 2;
                                   %         Z = Pcoeff/2*(1 + u);
                                   %     case 1
                                   %         r = 3;
                                   %         Z = (Pcoeff-1)/2*(1 + u^2) + 1;
                                   %     % Actually, r could be any positive integer
                                   %     % and Z(u) = z_0 + ... + z_ru^r,
                                   %     % where Z(1) = P(x) = Pcoeff.
                                   %     % Here we choice r=2 or 3, for convenience.
                                   % end
                           %% --------STEP 24
                           num = num+1;
                           M(num,:) = {s sigma b r Z tilde_d};
                           recip(num,1) = 1;
                       else
                           %when P(x) \ne constant
                           Bminus = Bdeg - Bdeg(1,:);
                           if rank(Bminus) == 1
                              Breduce = rref(Bminus);                         
                              preb = Breduce(1,:);
                              high = 0;
                              low  = 0;
                              maxpower  = 0;
                              for j=1:1:size(Bdeg,1)
                                  for l = 1:1:size(Bdeg,1)
                                      findb = Bdeg(j,:)-Bdeg(l,:);
                                      prer = unique(findb./preb);
                                      r = prer(1);
                                      if r > maxpower
                                          maxpower  = r;
                                          high  = j;
                                          low = l;
                                      end
                                  end
                              end
                              if high ~=0
                                  powerofB = zeros(1,size(Bdeg,1));
                                  for j=1:1:size(Bdeg,1)
                                      if j==low
                                         powerofB(j) = 0;
                                      else
                                         powerofB(j) = unique(nonzeros(Bdeg(j,:)-Bdeg(low,:))./nonzeros(preb));
                                      end
                                  end
                                  % [acA, acB] = sort(powerofB,'ascend');
                                  [dcA, dcB] = sort(powerofB,'descend');
                                  % bulid r and b
                                  R = union(factor(maxpower),[1,maxpower]);
                                  minpower = size(Pitem,2)-1;
                                  R = R(R>=minpower);
                                  R = setdiff(R,0); % Assume r ~= 0
                                  for r = R
                                      Z = 0;
                                      multi = maxpower./r;
                                      b = preb.*multi;
                                      for j=0:1:(max(dcA)-min(dcA))/multi
                                          if ismember(j*multi,dcA)
                                              l = dcA==j*multi;
                                              Z = Z+Pcoeff(dcB(l))*u^j;
                                          end
                                      end 
                                      num = num+1;
                                      %% --------STEP 24
                                      M(num,:) = {s sigma b r Z tilde_d};
                                      invZ = simplify(u^r*subs(Z,u,1/u));
                                      cZ = coeffs(Z,u);
                                      num = num+1;
                                      M(num,:) = {s sigma -b r invZ tilde_d};
                                      if and(isequal(Z, invZ), or(isequal(cZ(1),1),isequal(cZ(1),u/u)))
                                          recip(num,1) = 1;
                                          recip(num-1,1) = 1;
                                      else
                                          recip(num,1) = 0;
                                          recip(num-1,1) = 0;
                                      end
                                  end                       
                              end
                           end
                       end
                    end
                end
            end
        end
    end
end



%% ------------- Print results
disp('===========================================');
disp(['T(x) = ', sym2str(T)])
disp(['  d  = ', mat2str(d)])
disp(' ')
disp('The nontrivial 1-cluster symmetric pairs of T(x)x^{-d} are ')
disp(cell2table(M, "VariableNames", ["s" "sigma" "b" "r" "Z" "tilde{d}"]))
disp('===========================================');
end