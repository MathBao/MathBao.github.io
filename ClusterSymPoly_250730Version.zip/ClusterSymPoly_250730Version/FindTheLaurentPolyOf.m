function FindTheLaurentPolyOf(B,R,Z,Mutation,Permutation,eta,d)


%% ------- EXAMPLE 1
% % Find invariant Laurent polynomial of Example 2.25 for $\tilde{\alpha} = 5, \tilde{\beta} = 3$
% %% Input Data
% %% the seedlet $\omega_s = (b, r, Z)$
% b = [0,1,-1,-1,1];  % tuple $\mathbf{b}$
% r = 1;               
% Z = [3, 5]; % coefficients of the polynomial Z(u)=3+5u
% 
% s = 1;  % direction $s$
% sigma = [2,3,4,5,1]; % permuation $\sigma_{(12345)}$, where sigma(i) is $\sigma_{(12345)}(i)$
% eta = [2,3,4,3,2]; % $\bm\eta$
% d = [1,1,1,1,1];   % $\mathbf{d}$
% 
% %% Solve the system of homogeneous linear equation $HLE(\sigma, s, \omega_s, \bm{\eta}, \mathbf{d})$
% FindTheLaurentPolyOf(b,r,Z,s,sigma,eta,d);

%% ------- EXAMPLE 2
% Find invariant Laurent polynomial of Question 3.28
% %% Input the seed $\Omega = (B, R, \mathbf{Z})$
% B = [0, 1,-1;
%     -1, 0, 2;
%      1,-2, 0];
% R = [4,1,1];
% syms k1 k2
% Z = [1, k1,k2,k1,1;
%      1, 1, 0, 0, 0;
%      1, 1, 0, 0, 0];
% 
% S = [1;2;3]; % direction list S
% Sigma = [1:3; 1:3; 1:3]; % permuation list Sigma
% eta = [2,4,4]; % $\bm\eta$
% d = [1,2,2];   % $\mathbf{d}$
% 
% %% Solve the systems of homogeneous linear equation $HLE(\sigma, s, \omega_s, \bm{\eta}, \mathbf{d})$ for all $s \in S$
% FindTheLaurentPolyOf(B,R,Z,S,Sigma,eta,d);

% =========================================================================


%% --- Preprocessing the data. 
% If B is a vector, then convert it to a martix.
if size(B,1) == 1
   m = size(B,2);
   B = ones(m).*B';
   Z = ones(m,R+1).*Z;
   R = eye(m)*R;
end


%% ------------- Preparation, adjusting subscripts
% The actual subscripts start at 0, while matlab starts at 1.
n = size(B,1);
fix = ones(1,n);
eta_fix = eta + fix;

%% ------- Construct the set $\mathcal{N}$, where each row is an index.
N = zeros(prod(eta_fix), n);
for i = 2:1:size(N,1)
    N(i,:) = N(i-1,:);
    N(i,n) = N(i,n)+1;
    for j = n:-1:2
        if N(i,j) > eta(j)
            N(i,j) = 0;
            N(i,j-1) = N(i,j-1) + 1;
        end
    end
end

%% --- Construct the matrix A of the system of homogeneous linear equations $HLE$
if isa(Z,'sym')
    A = sym('A', [1,prod(eta_fix)]);
else
    A = zeros(1,prod(eta_fix));
end
A(1,1:end) = 0; 
eqnNum = 1;

for t = 1:1:size(Mutation,1)
    s = Mutation(t,1);
    sigma = Permutation(t,:);

    [~, iSigma] = sort(sigma, 2); % iSigma is the inverse of the permutation sigma
    iSig_N = N(:, iSigma); % The set $sigma^{-1}(N) = \{\sigma(\mathbf{j}) \mid \mathbf{j} \in N \}$

    for k = 0:1:d(s)
        
        %% --- Construct the set $\bigcup \mathcal{N} + b_{s,k,l}^{(2k)}$，
        % and the set $\bigcup \sigma^{-1}(\mathcal{N})+B$.
        N_B = N + vec(B,R,s,k,0,2*k);
        iSig_N_B = iSig_N + vec(B,R,s,k,0,2*k);
        for l = 1:1:k*R(s) 
            N_B = union(N_B, N + vec(B,R,s,k,l,2*k), 'rows');
            iSig_N_B = union(iSig_N_B, iSig_N + vec(B,R,s,k,l,2*k), 'rows');
        end
        
        %% --- Construct $HLE(\sigma, s, \omega_s, \bm{\eta}, \mathbf{d}, k)$
        % Equations A1, A2, A3
        % ------------- (A1) 0 = a_{sigam(j)} - sum a_{j-B}
        set = intersect(iSig_N, N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1. Construct equation $\Sum a_{j-b}$
            for l = 0:1:k*R(s)
                if ismember(bf_j - vec(B,R,s,k,l,2*k), N, 'rows') 
                    index = ismember(N, bf_j - vec(B,R,s,k,l,2*k), 'rows');
                    A(eqnNum, index) = A(eqnNum, index) + coeff(R,Z,s,k,l);        
                end
            end
            % 2. Construct a_{sigma(j)}
            index = ismember(N, bf_j(sigma), 'rows');
            A(eqnNum, index) = A(eqnNum, index)-1;
            % 3. An equation has been constructed
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        % Simplify A by Gauss elimination to avoid the matrix A being too large.
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;

        % ------------- (A2) sum a_{j-B} = 0
        set = setdiff(N_B,iSig_N, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1. Construct Sum a_{j-B}
            for l = 0:1:k*R(s)
                if ismember(bf_j - vec(B,R,s,k,l,2*k), N, 'rows') 
                    index = ismember(N, bf_j - vec(B,R,s,k,l,2*k), 'rows');
                    A(eqnNum, index) = A(eqnNum, index)+coeff(R, Z ,s,k,l);
                end
            end
            % 2. An equation has been constructed
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        % Simplify A by Gauss elimination to avoid the matrix A being too large.
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;

        % ------------- (A3) a_sig_j = 0
        set = setdiff(iSig_N,N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);

        for j = 1:1:size(pi_set,1)

            bf_j = pi_set(j,:);

            % 2.Construct a_{sigma(j)}
            index = ismember(N, bf_j(1,sigma), 'rows');
            A(eqnNum, index) = A(eqnNum, index) - 1;
            % An equation has been constructed
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        
        %% --- Construct $HLE(\sigma^{-1}, t, \omega_t, \bm{\eta}, \mathbf{d}, k)$
        % Equations C1,C2,C3
        %  (C1) 0 = a_{j} - sum a_{sigma(j-B)}
        set = intersect(N, iSig_N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1.Construct Sum a_{j-B}
            for l = 0:1:k*R(s)
                bf_j_vec = bf_j - vec(B,R,s,k,l,2*k);
                bf_j_vec = bf_j_vec(sigma);
                if ismember(bf_j_vec, N, 'rows')
                    index = ismember(N, bf_j_vec, 'rows');
                    A(eqnNum, index) = A(eqnNum, index) + coeff(R,Z,s,k,l);
                end
            end
            % 2.Construct a_{j}
            index = ismember(N, bf_j, 'rows');
            A(eqnNum, index) = A(eqnNum, index) - 1;
            % 3.An equation has been constructed
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        % Simplify A by Gauss elimination to avoid the matrix A being too large.
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;
        
        %% ------------- (C2) 0 = sum a_{sigma(j-B)}
        set = setdiff(iSig_N_B, N, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1.Construct Sum a_{j-B}
            for l = 0:1:k*R(s)
                bf_j_vec = bf_j - vec(B,R,s,k,l,2*k);
                bf_j_vec = bf_j_vec(sigma);
                if ismember(bf_j_vec, N, 'rows')
                    index = ismember(N, bf_j_vec, 'rows');
                    A(eqnNum, index) = A(eqnNum, index) + coeff(R,Z,s,k,l);
                end
            end
            % 3.An equation has been constructed
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        % Simplify A by Gauss elimination to avoid the matrix A being too large.
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;

        %% ------------- (C3) 0 = a_{j}
        set = setdiff(N, iSig_N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);

        for j = 1:1:size(pi_set,1)

            bf_j = pi_set(j,:);

            % 2.Construct a_{j}
            index = ismember(N, bf_j, 'rows');
            A(eqnNum, index) = A(eqnNum, index) - 1;

            % 3.An equation has been constructed
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        % Simplify A by Gauss elimination to avoid the matrix A being too large.
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;
    end

    % Simplify A by Gauss elimination to avoid the matrix A being too large.
    A = rref(A);
    eqnNum = size(A,1)+1;
    A(eqnNum, 1) = 0;
end

%% ------------- Solve the system of homoegeneous linear equations A
if isa(Z,'sym')
    sol = null(A);
else
    sol = null(A, 'r');
end
[row, col, val] = find(sol);


%% ---------- Print results
disp('=======================================================');
disp('The solution is');
blank = '   ';
for b=1:1:n-4
    blank = [blank, '   '];
end 
disp(['  Class  Coefficent  Subscript  ', blank ,'Monomial'])
class = 0;
for j = 1:1:size(col,1)  
    if j > 1
        if col(j-1)~=col(j)
            class = class + 1;
        end
    elseif j == 1
        class = class + 1;
    end

    multiple = val(j);
    subscript =  N(row(j),:);
    monomial = [];
    for t = 1:1:n
        if subscript(t)~=0
            if subscript(t) == 1
                monomial = [monomial, ['x_',num2str(t)]];
            else
                monomial = [monomial, ['x_',num2str(t),'^',num2str(subscript(t))]];
            end
        end
    end
    disp(['    ', num2str(class), '       ',sym2str(multiple),'       ',num2str(subscript),'    ', monomial] );
end

% Organize Calculated Results
disp(' ');
disp('Hence we have');
x = sym('x_', [1,n]);
uniCol = unique(col);

s_f = x(1);
s_f(1) = [];
for j = 1:1:class
    [index, ~] = find(col == uniCol(j));
    for i = 1:1:size(index,1)
        mono = val(index(i)).*prod(x.^N(row(index(i)),:));
        if i == 1
            f = mono;
        else
            f = f + mono;
        end
    end
    
    s_f(j) = simplify(f);
    fprintf('  The polynomial of Class %d is:\n       %s\n',j, s_f(j));
    
    %sym2latex(s_f);
end
disp('=======================================================');


% %% Show LaTeX
% 
% colum_add = 1 + n+ 1 + n + 2+1+1;
% 
% poly = strings(class*2 + colum_add,1);
% 
% poly(1, 1) = ['The exchange matrix $B$ is'];
% poly(2:n+1, 1) = num2str(B);
% poly(n+2, 1) = ['$R = diag($', num2str(R),'$)$'];
% 
% % show_Z = zeros(size(Z,1),size(Z,2)+2);
% % show_Z(:,1) = 1;
% % show_Z(:,end) = 1;
% % show_Z(:,2:end-1) = Z;
% % syms u;
% % 
% % for j = 1:1:size(Z,1)
% %     ZZ = u.^[0:size(show_Z,2)-1]*(show_Z(j,:))';
% %     poly(n+2+j, 1) = ['$Z_{',num2str(j),'}(u) = ', latex(ZZ),'$'];
% % end
% 
% 
% syms u;
% 
% for j = 1:1:size(Z,1)
%     ZZ = u.^[0:size(Z,2)-1]*(Z(j,:))';
%     poly(n+2+j, 1) = ['$Z_{',num2str(j),'}(u) = ', latex(ZZ),'$'];
% end
% 
% poly(n+2+n+1, 1) = ['$$\eta = (', num2str(eta) ,')$$'];
% poly(n+2+n+2, 1) = ['$$d = (', num2str(d) ,')$$'];
% 
% poly(colum_add-1, 1) = '';
% poly(colum_add, 1) = ['---------------ANS---------------'];
% 
% for j = 1:1:class
% 	poly(2*j-1+ colum_add, 1) = ['The polynomial of Class ', num2str(j),' is'];
% 	poly(2*j + colum_add, 1) =   ['   ', '$$', latex(s_f(j)),'$$'];
% 
% end
% sym2latex(poly);

end