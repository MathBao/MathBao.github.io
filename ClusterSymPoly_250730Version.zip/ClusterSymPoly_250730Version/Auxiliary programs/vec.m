% 计算向量 b_{s,k,l}^{(i)} := l[B_s]_{+} + (kr-l)[-B]_+ - ie_s
function A = vec(B,R,s,k,l,i)

B_s = B(:,s);
B_s_p = B_s;
B_s_p(B_s < 0) = 0;
B_s_n = B_s;
B_s_n(B_s > 0) = 0;

e_s = zeros(size(B_s,1),1);
e_s(s) = 1;

C = l*B_s_p + (k*R(s) - l)*(-B_s_n) - i*e_s;
A = C';
end